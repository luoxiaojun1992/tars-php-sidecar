<?php
return array(
    'appName' => 'PHPTars',
    'serverName' => 'PHPTarsSidecar',
    'objName' => 'obj',
);
